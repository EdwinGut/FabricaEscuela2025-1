// Datos de ejemplo para los usuarios
export const mockUsers = [
  {
    id: "1",
    name: "Técnico Demo",
    email: "tecnico@telconova.com",
    role: "technician",
  },
  {
    id: "2",
    name: "Administrador",
    email: "admin@telconova.com",
    role: "admin",
  },
]
